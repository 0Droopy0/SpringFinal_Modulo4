package sprintModulo4;

public enum SistemaSalud {
	FONASA, ISAPRE
}
