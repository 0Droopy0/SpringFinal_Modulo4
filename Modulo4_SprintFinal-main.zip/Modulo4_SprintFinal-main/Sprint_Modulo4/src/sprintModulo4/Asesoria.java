package sprintModulo4;

public interface Asesoria {
	void analizarUsuario();
}
