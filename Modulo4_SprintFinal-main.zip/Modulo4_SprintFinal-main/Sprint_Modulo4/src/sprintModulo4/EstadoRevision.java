package sprintModulo4;

public enum EstadoRevision {
	SIN_PROBLEMAS,
	CON_OBSERVACIONES,
	NO_APRUEBA;
}
